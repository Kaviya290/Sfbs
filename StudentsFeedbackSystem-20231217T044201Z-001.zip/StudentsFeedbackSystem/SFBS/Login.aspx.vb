﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Imports System.Configuration




Public Class Login
    Inherits System.Web.UI.Page

    Dim db_path As String
    Dim db_cmd, db_cmd1 As New SqlCommand
    Dim db_con As New SqlConnection
    Dim db_read As SqlDataReader
    Dim db_adpt As New SqlDataAdapter
    Dim db_datatable As New DataTable

    Dim login_Check, login_passQuery, login_Password As String
    Dim login_temp As Integer



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub


    Protected Sub radio_logintype_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_logintype.SelectedIndexChanged
        'If radio_logintype.SelectedItem.Text = "staff" Then

        '    txt_stafflogin.Visible = True
        '    txt_adminname.Visible = False
        '    txt_stafflogin.Text = ""

        '    txt_stafflogin.Attributes.Add("readonly", "true")
        '    login_namevalid.ControlToValidate = "txt_stafflogin"

        'ElseIf radio_logintype.SelectedItem.Text = "admin" Or radio_logintype.SelectedItem.Text = "student" Then
        '    txt_stafflogin.Visible = False
        '    txt_adminname.Visible = True

        '    txt_adminname.Text = ""
        '    login_namevalid.ControlToValidate = "txt_adminname"
        'End If
    End Sub

    Protected Sub btn_login_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btn_login.Click

        Try
            'ADMIN LOGIN

            If radio_logintype.SelectedItem.Text = "Admin" Then

                Try

                    db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString
                    db_con = New SqlConnection(db_path)
                    db_con.Open()

                    login_Check = "select count(*) from SFBS_ADMIN where SFBS_admin_Name ='" + txt_adminname.Text + "'"
                    db_cmd = New SqlCommand(login_Check, db_con)
                    login_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString)
                    db_con.Close()
                    If login_temp = 1 Then
                        db_con.Open()
                        login_passQuery = "select SFBS_admin_Pass from SFBS_ADMIN where SFBS_admin_Name ='" + txt_adminname.Text + "' "
                        db_cmd1 = New SqlCommand(login_passQuery, db_con)
                        login_Password = db_cmd1.ExecuteScalar().ToString.Replace(" ", "")

                        If login_Password = txt_adminpass.Text Then
                            Session("login_userSession") = txt_adminname.Text
                            Response.Redirect("SFBS-Admin/adminhome.aspx")
                        Else
                            lbl_loginerrmsg.Text = "Password Mismatch"
                        End If
                        ' lbl_loginerrmsg.Text = "Password Mismatch"
                    Else
                        lbl_loginerrmsg.Text = "Username Mismatch"


                    End If

                Catch ex As Exception
                    lbl_loginerrmsg.Text = ex.Message
                Finally
                    db_con.Close()
                End Try


                'STAFF LOGIN

            ElseIf radio_logintype.SelectedItem.Text = "Staff" Then


                Try

                    db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString
                    db_con = New SqlConnection(db_path)
                    db_con.Open()

                    login_Check = "select count(*) from SFBS_STAFF where SFBS_staffMobile ='" + txt_adminname.Text + "'"
                    db_cmd = New SqlCommand(login_Check, db_con)
                    login_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString)
                    db_con.Close()
                    If login_temp = 1 Then
                        db_con.Open()
                        login_passQuery = "select SFBS_staffMobile,SFBS_staffName,SFBS_staffDOJ,SFBS_staffCourse,SFBS_staffDept from SFBS_STAFF where SFBS_staffMobile ='" + txt_adminname.Text + "' "
                        db_cmd1 = New SqlCommand(login_passQuery, db_con)
                        login_Password = db_cmd1.ExecuteScalar().ToString.Replace(" ", "")
                        db_read = db_cmd1.ExecuteReader()
                        db_read.Read()


                        If login_Password = txt_adminpass.Text Then
                            Session("staff_usersession") = db_read("SFBS_staffName")
                            Session("staff_Mobile") = db_read("SFBS_staffMobile")
                            Session("staff_DOJ") = db_read("SFBS_staffDOJ")
                            Session("staff_Department") = db_read("SFBS_staffDept")
                            Session("staff_Course") = db_read("SFBS_staffCourse")

                            Response.Redirect("SFBS-Staff/staffhome.aspx")
                        Else
                            
                            lbl_loginerrmsg.Text = "Password Mismatch"
                        End If

                    Else
                        lbl_loginerrmsg.Text = "Username Mismatch"


                    End If

                Catch ex As Exception
                    lbl_loginerrmsg.Text = ex.Message
                Finally
                    db_con.Close()
                End Try



                'STUDENT LOGIN

            ElseIf radio_logintype.SelectedItem.Text = "Student" Then

                Try

                    db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString
                    db_con = New SqlConnection(db_path)
                    db_con.Open()

                    login_Check = "select count(*) from SFBS_STUDENT where SFBS_studentUN ='" + txt_adminname.Text + "'"
                    db_cmd = New SqlCommand(login_Check, db_con)
                    login_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString)
                    db_con.Close()
                    If login_temp = 1 Then
                        db_con.Open()
                        login_passQuery = "select SFBS_studentPS,SFBS_studentRegno,SFBS_studentName,SFBS_studentCourse,SFBS_studentDept from SFBS_STUDENT where SFBS_studentUN ='" + txt_adminname.Text + "' "
                        db_cmd1 = New SqlCommand(login_passQuery, db_con)
                        login_Password = db_cmd1.ExecuteScalar().ToString.Replace(" ", "")
                        db_read = db_cmd1.ExecuteReader()
                        db_read.Read()


                        If login_Password = txt_adminpass.Text Then
                            Session("student_usersession") = db_read("SFBS_studentName")
                            Session("student_regno") = db_read("SFBS_studentRegno")
                            Session("student_Course") = db_read("SFBS_studentCourse")
                            Session("student_Dept") = db_read("SFBS_studentDept")
                            'Session("student_Year") = db_read("SFBS_studentYear")


                            Response.Redirect("SFBS-Student/studenthome.aspx")
                        Else
                           
                            lbl_loginerrmsg.Text = "Password Mismatch"
                        End If

                    Else
                        lbl_loginerrmsg.Text = "Username Mismatch"


                    End If

                Catch ex As Exception
                    lbl_loginerrmsg.Text = ex.Message
                Finally
                    db_con.Close()
                End Try


            End If

        Catch ex As Exception
            lbl_loginerrmsg.Text = "Please Select Valid Login"
        End Try

    End Sub

  
End Class