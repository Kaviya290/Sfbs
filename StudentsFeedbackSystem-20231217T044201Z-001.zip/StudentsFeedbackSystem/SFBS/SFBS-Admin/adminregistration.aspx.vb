﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Imports System.Configuration


Public Class adminregistration
    Inherits System.Web.UI.Page

    Dim db_path As String
    Dim db_cmd As New SqlCommand
    Dim db_con As New SqlConnection
    Dim db_read As SqlDataReader
    Dim db_adpt As New SqlDataAdapter
    Dim db_datatable As New DataTable

    Dim reg_check, reg_insert As String

    Dim student_Pass As String

    Dim reg_temp, staff_Entered, staff_Remain, staff_Total As Integer



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load



        If Page.IsPostBack = False Then

            If Session("login_userSession") = Nothing Or Session("login_userSession") = "" Then
                Response.Redirect("../Login.aspx")
            Else

                lbl_adminhomeseshead.Text = "Welcome : " + Session("login_userSession")

                panel_regdept.Visible = False
                panel_regstaff.Visible = False
                panel_regstudent.Visible = False


                resetFields()
            End If

        End If


    End Sub

    Protected Sub radio_regtype_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_regtype.SelectedIndexChanged
        If radio_regtype.SelectedItem.Text = "DEPARTMENT" Then
            panel_regdept.Visible = True
            panel_regstaff.Visible = False
            panel_regstudent.Visible = False
            resetFields()

        ElseIf radio_regtype.SelectedItem.Text = "STAFF" Then
            panel_regdept.Visible = False
            panel_regstaff.Visible = True
            panel_regstudent.Visible = False
            resetFields()

        ElseIf radio_regtype.SelectedItem.Text = "STUDENT" Then
            panel_regdept.Visible = False
            panel_regstaff.Visible = False
            panel_regstudent.Visible = True
            resetFields()
        End If
    End Sub


    Public Sub resetFields()
        txt_regdeptId.Text = ""
        txt_regdeptName.Text = ""
        txt_regdeptStaff.Text = ""
        txt_regstdoj.Text = ""
        txt_regstdes.Text = ""
        txt_regstmbl.Text = ""
        txt_regstexp.Text = ""
        txt_regstname.Text = ""
        txt_regstucpass.Text = ""
        txt_regstuid.Text = ""
        txt_regstumail.Text = ""
        txt_regstuname.Text = ""
        txt_regstupass.Text = ""
        txt_regstuphone.Text = ""
        txt_regstuuname.Text = ""
        txt_regstucpass.Attributes("Value") = ""
        txt_regstupass.Attributes("Value") = ""

        radio_regstgender.ClearSelection()
        radio_regstugender.ClearSelection()
        radio_regdeptcourse.ClearSelection()
        radio_regstcour.ClearSelection()
        ddl_regstdept.ClearSelection()
        ddl_regstudept.ClearSelection()
        ddl_regstuyear.ClearSelection()
        chk_regstulogin.Checked = False

        ddl_regstdept.Items.Clear()
        ddl_regstudept.Items.Clear()
        ddl_regstuyear.Items.Clear()

        lbl_deptentstaff.Text = ""
        lbl_depttotstaff.Text = ""

        radio_regstucourse.ClearSelection()

        txt_regstuuname.Enabled = True
        txt_regstupass.Enabled = True
        txt_regstucpass.Enabled = True

        ddl_regstudept.Items.Insert(0, New ListItem("-- Select Department --"))
        ddl_regstuyear.Items.Insert(0, New ListItem("-- Select Year --"))

        ddl_regstdept.Items.Insert(0, New ListItem("-- Select Department --"))

        valid_stuPass.Visible = True
        valid_stuCPass.Visible = True
        
        'panel_regdept.Visible = False
        'panel_regstaff.Visible = False
        'panel_regstudent.Visible = False

        'radio_regtype.ClearSelection()


        ' lbl_regdeptmsg.Text = ""
        ' lbl_regstmsg.Text = ""
    End Sub


    Protected Sub btn_regdept_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btn_regdept.Click

        Try


            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_insert = "insert into SFBS_Department (SFBS_deptCourse,SFBS_deptID,SFBS_deptName,SFBS_deptNStaff) values ('" + radio_regdeptcourse.SelectedItem.Text + "','" + txt_regdeptId.Text + "','" + txt_regdeptName.Text + "','" + txt_regdeptStaff.Text + "') "
            db_cmd = New SqlCommand(reg_insert, db_con)
            db_cmd.ExecuteNonQuery()
            lbl_regdeptmsg.Text = "Deparment Sucessfully Added"

            'reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString)


            db_con.Close()

            resetFields()


        Catch ex As Exception
            lbl_regdeptmsg.Text = "Problem in Adding : " + ex.ToString

        End Try



    End Sub


    Protected Sub txt_regstdoj_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txt_regstdoj.TextChanged

        Dim selectedDate, currentDate As Date
        Dim expyear As Integer


        currentDate = DateTime.Now
        selectedDate = Convert.ToDateTime(txt_regstdoj.Text).Date

        expyear = currentDate.Year - selectedDate.Year

        txt_regstexp.Text = expyear

    End Sub

    Protected Sub btn_regstadd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btn_regstadd.Click
        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_insert = "insert into SFBS_STAFF (SFBS_staffName,SFBS_staffCourse,SFBS_staffDept,SFBS_staffGender,SFBS_staffDesignation, SFBS_staffMobile,SFBS_staffDOJ,SFBS_staffExp) values ('" + txt_regstname.Text + "','" + radio_regstcour.SelectedItem.Text + "','" + ddl_regstdept.SelectedItem.Text + "','" + radio_regstgender.SelectedItem.Text + "','" + txt_regstdes.Text + "','" + txt_regstmbl.Text + "','" + txt_regstdoj.Text + "','" + txt_regstexp.Text + "') "
            db_cmd = New SqlCommand(reg_insert, db_con)
            db_cmd.ExecuteNonQuery()
            lbl_regstmsg.Text = "Staff Detail Added"

            'reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString)


            db_con.Close()

            resetFields()


        Catch ex As Exception
            lbl_regstmsg.Text = "Problem Adding " + ex.ToString

        End Try

    End Sub

    Protected Sub ddl_regstdept_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_regstdept.SelectedIndexChanged


        Try
            ddl_regstdept.Items(0).Attributes("Disabled") = "Disable"

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select SFBS_deptNStaff from SFBS_Department where SFBS_deptCourse='" + radio_regstcour.SelectedItem.Text + "' and SFBS_deptName ='" + ddl_regstdept.SelectedItem.Text + "' "
            db_cmd = New SqlCommand(reg_check, db_con)
            db_read = db_cmd.ExecuteReader()


            db_read.Read()

            lbl_depttotstaff.Visible = True

            staff_Total = db_read("SFBS_deptNStaff")
            lbl_depttotstaff.Text = "Staff Strength :- " + db_read("SFBS_deptNStaff").ToString()
            db_con.Close()


            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select count(SFBS_StaffDept) from SFBS_STAFF where SFBS_staffDept='" + ddl_regstdept.SelectedItem.Text + "' and SFBS_staffCourse ='" + radio_regstcour.SelectedItem.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            'reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString())

            staff_Entered = Convert.ToInt32(db_cmd.ExecuteScalar())

            ' db_read = db_cmd.ExecuteReader()
            ' db_read.Read()

            staff_Remain = staff_Total - staff_Entered

            lbl_deptentstaff.Visible = True
            lbl_deptentstaff.Text = "Total Entry :- " & staff_Entered.ToString & " Remaing Entry :- " & staff_Remain.ToString

            db_con.Close()

            If staff_Remain <> 0 Then
                txt_regstname.Enabled = True
                radio_regstgender.Enabled = True
                txt_regstdes.Enabled = True
                txt_regstdoj.Enabled = True
                txt_regstmbl.Enabled = True
                btn_regstadd.Enabled = True
                lbl_deptentstaff.Visible = True
                lbl_depttotstaff.Visible = True
                lbl_stafffilled.Visible = False

            Else
                txt_regstname.Enabled = False
                radio_regstgender.Enabled = False
                txt_regstdes.Enabled = False
                txt_regstdoj.Enabled = False
                txt_regstmbl.Enabled = False
                btn_regstadd.Enabled = False
                lbl_deptentstaff.Visible = False
                lbl_depttotstaff.Visible = False

                lbl_stafffilled.Visible = True

                lbl_stafffilled.Text = "STAFF ENTRY FULL. PLEASE SELECT ANOTHER DEPARTMENT."
            End If

        Catch ex As Exception
            Response.Write("Error :- " & ex.ToString)
        End Try

    End Sub

    Protected Sub radio_regstcour_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_regstcour.SelectedIndexChanged

        lbl_deptentstaff.Visible = False
        lbl_depttotstaff.Visible = False



        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select SFBS_deptName from SFBS_department where SFBS_deptCourse = '" + radio_regstcour.SelectedItem.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            db_read = db_cmd.ExecuteReader()



            'db_adpt = New SqlDataAdapter(reg_check, db_con)
            'db_datatable = New DataTable()
            'db_adpt.Fill(db_datatable)



            'db_read = db_cmd.ExecuteReader()

            ddl_regstdept.DataSource = db_read

            ddl_regstdept.DataTextField = "SFBS_deptName"
            ddl_regstdept.DataValueField = "SFBS_deptName"
            ddl_regstdept.DataBind()


            ddl_regstdept.ClearSelection()


            ddl_regstdept.Items.Insert(0, New ListItem("-- Select Department --"))
            ddl_regstdept.SelectedIndex = 0


            'ddl_regstdept.Items.Insert(0, " -- Choose Department --")
            'ddl_regstdept.Items(0).Selected = True
            'ddl_regstdept.Items(0).Attributes("Disabled") = "Disabled"


        Catch ex As Exception

        Finally
            db_con.Close()
        End Try

      
    End Sub

    Protected Sub btn_regstuadd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btn_regstuadd.Click

        Try

            If txt_regstupass.Attributes("Value") <> txt_regstuphone.Text Then
                txt_regstupass.Attributes("Value") = txt_regstupass.Text
            Else
                txt_regstupass.Attributes("Value") = txt_regstuphone.Text
            End If

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_insert = "insert into SFBS_STUDENT (SFBS_studentRegno,SFBS_studentName,SFBS_studentGender,SFBS_studentCourse,SFBS_studentDept,SFBS_studentYear,SFBS_studentMailid,SFBS_studentMobile,SFBS_studentUN,SFBS_studentPS) values ('" + txt_regstuid.Text + "','" + txt_regstuname.Text + "','" + radio_regstugender.SelectedItem.Text + "','" + radio_regstucourse.SelectedItem.Text + "','" + ddl_regstudept.SelectedItem.Text + "','" + ddl_regstuyear.SelectedItem.Text + "','" + txt_regstumail.Text + "','" + txt_regstuphone.Text + "','" + txt_regstuuname.Text + "','" + txt_regstupass.Attributes("Value") + "') "
            db_cmd = New SqlCommand(reg_insert, db_con)
            db_cmd.ExecuteNonQuery()
            lbl_regstumsg.Text = "Student Detail Added"

            'reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString)


            db_con.Close()

            resetFields()


        Catch ex As Exception
            lbl_regstumsg.Text = "Problem Adding " + ex.ToString

        End Try

    End Sub

    Protected Sub txt_regdeptId_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txt_regdeptId.TextChanged

        Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select count(*) from SFBS_Department where SFBS_deptId ='" + txt_regdeptId.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString)



            If reg_temp = 1 Then
                lbl_regdeptchk.Visible = True
                lbl_regdeptchk.Text = "Department Id Already Exists."
                btn_regdept.Enabled = False

                'txt_regdeptName.Enabled = False
                'txt_regdeptStaff.Enabled = False

            Else
                'lbl_regdeptchk.Text = "Reg-Temp value is 0 : " + reg_temp.ToString
                'txt_regdeptName.Enabled = True
                'txt_regdeptStaff.Enabled = True
                btn_regdept.Enabled = True
                lbl_regdeptchk.Visible = False
            End If
            db_con.Close()
        Catch ex As Exception
            lbl_regdeptchk.Text = "Some Error : " + ex.ToString

        End Try
        


    End Sub

    Protected Sub txt_regstmbl_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txt_regstmbl.TextChanged
        Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select count(*) from SFBS_STAFF where SFBS_staffMobile = '" + txt_regstmbl.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString())



            If reg_temp = 1 Then
                'db_con.Open()
                lbl_regstphonecheck.Visible = True
                lbl_regstphonecheck.Text = "Mobile Number Already Registered"
                txt_regstmbl.Focus()
                btn_regstadd.Enabled = False



                'txt_regstdoj.Enabled = False
            Else
                'txt_regstdoj.Enabled = True
                lbl_regstphonecheck.Visible = False
                btn_regstadd.Enabled = True
            End If

            db_con.Close()

        Catch ex As Exception
            lbl_regstphonecheck.Text = "Database Error"
        End Try
    End Sub

    Protected Sub txt_regstuid_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txt_regstuid.TextChanged

        Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select count(*) from SFBS_STUDENT where SFBS_studentRegno = '" + txt_regstuid.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString())



            If reg_temp = 1 Then
                'db_con.Open()
                lbl_regstuidchk.Visible = True
                lbl_regstuidchk.Text = "Duplicate Register Id Found"
                txt_regstuid.Focus()
                btn_regstuadd.Enabled = False
            Else

                btn_regstuadd.Enabled = True
                lbl_regstuidchk.Visible = False
            End If



        Catch ex As Exception
            lbl_regstuidchk.Text = "Database Error"
        Finally
            db_con.Close()
        End Try

    End Sub

    

    Protected Sub txt_regstumail_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txt_regstumail.TextChanged

        Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select count(*) from SFBS_STUDENT where SFBS_studentMailid = '" + txt_regstumail.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString())



            If reg_temp = 1 Then
                'db_con.Open()
                lbl_regstumailchk.Visible = True
                lbl_regstumailchk.Text = "Duplicate Mail-Id Found"
                txt_regstumail.Focus()
                btn_regstuadd.Enabled = False
            Else

                btn_regstuadd.Enabled = True
                lbl_regstumailchk.Visible = False
            End If



        Catch ex As Exception
            lbl_regstuidchk.Text = "Database Error"
        Finally
            db_con.Close()
        End Try

    End Sub

    Protected Sub txt_regstuphone_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txt_regstuphone.TextChanged

        Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select count(*) from SFBS_STUDENT where SFBS_studentMobile = '" + txt_regstuphone.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString())



            If reg_temp = 1 Then
                'db_con.Open()
                lbl_regstumblchk.Visible = True
                lbl_regstumblchk.Text = "Duplicate Phone No. Found"
                txt_regstuphone.Focus()
                btn_regstuadd.Enabled = False
            Else

                btn_regstuadd.Enabled = True
                lbl_regstumblchk.Visible = False
            End If



        Catch ex As Exception
            lbl_regstuidchk.Text = "Database Error"
        Finally
            db_con.Close()
        End Try

    End Sub

    Protected Sub txt_regstuuname_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txt_regstuuname.TextChanged
        Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select count(*) from SFBS_STUDENT where SFBS_studentUN = '" + txt_regstuuname.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            reg_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString())



            If reg_temp = 1 Then
                'db_con.Open()
                lbl_regstuUNchk.Visible = True
                lbl_regstuUNchk.Text = "User Name Already Taken"
                txt_regstuuname.Focus()
                btn_regstuadd.Enabled = False
            Else

                btn_regstuadd.Enabled = True
                lbl_regstuUNchk.Visible = False
            End If



        Catch ex As Exception
            lbl_regstuidchk.Text = "Database Error"
        Finally
            db_con.Close()
        End Try
    End Sub

    Protected Sub chk_regstulogin_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chk_regstulogin.CheckedChanged

        If txt_regstuid.Text <> "" And txt_regstuphone.Text <> "" Or txt_regstuid.Text <> Nothing And txt_regstuphone.Text <> Nothing Then

            If chk_regstulogin.Checked = True Then
                txt_regstuuname.Text = txt_regstuid.Text
                txt_regstupass.Attributes("Value") = txt_regstuphone.Text
                txt_regstucpass.Attributes("Value") = txt_regstuphone.Text

                valid_stuPass.Visible = False
                valid_stuCPass.Visible = False


                'txt_regstupass.Text = txt_regstupass.Attributes("Value")
                'txt_regstucpass.Text = txt_regstucpass.Attributes("Value")


                txt_regstuuname.Enabled = False
                txt_regstupass.Enabled = False
                txt_regstucpass.Enabled = False
            ElseIf chk_regstulogin.Checked = False Then

                txt_regstuuname.Text = ""
                txt_regstupass.Text = ""
                txt_regstucpass.Text = ""

                txt_regstuuname.Attributes("Value") = ""
                txt_regstupass.Attributes("Value") = ""
                txt_regstucpass.Attributes("Value") = ""

                valid_stuPass.Visible = True
                valid_stuCPass.Visible = True

                txt_regstuuname.Enabled = True
                txt_regstupass.Enabled = True
                txt_regstucpass.Enabled = True

            End If

        Else
            chk_regstulogin.Checked = False

            txt_regstuuname.Text = ""
            txt_regstupass.Text = ""
            txt_regstucpass.Text = ""
            valid_stuPass.Visible = True
            valid_stuCPass.Visible = True

            txt_regstuuname.Attributes("Value") = ""
            txt_regstupass.Attributes("Value") = ""
            txt_regstucpass.Attributes("Value") = ""

            txt_regstuuname.Enabled = True
            txt_regstupass.Enabled = True
            txt_regstucpass.Enabled = True
        End If

    End Sub

    Protected Sub radio_regstucourse_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_regstucourse.SelectedIndexChanged
        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            reg_check = "select SFBS_deptName from SFBS_Department where SFBS_deptCourse = '" + radio_regstucourse.SelectedItem.Text + "'"
            db_cmd = New SqlCommand(reg_check, db_con)
            db_read = db_cmd.ExecuteReader()



            'db_adpt = New SqlDataAdapter(reg_check, db_con)
            'db_datatable = New DataTable()
            'db_adpt.Fill(db_datatable)



            'db_read = db_cmd.ExecuteReader()

            ddl_regstudept.DataSource = db_read

            ddl_regstudept.DataTextField = "SFBS_deptName"
            ddl_regstudept.DataValueField = "SFBS_deptName"
            ddl_regstudept.DataBind()

            ddl_regstudept.Items.Insert(0, New ListItem("-- Select Department --"))
            ddl_regstudept.SelectedIndex = 0

            ddl_regstuyear.Items.Clear()
            ddl_regstudept.ClearSelection()

            If radio_regstucourse.SelectedItem.Text = "UG" Then

                


                ddl_regstuyear.Items.Add("I Year")
                ddl_regstuyear.Items.Add("II Year")
                ddl_regstuyear.Items.Add("III Year")
               
            ElseIf radio_regstucourse.SelectedItem.Text = "PG" Then


                'ddl_regstuyear.Items.Clear()
                ddl_regstuyear.Items.Add("I Year")
                ddl_regstuyear.Items.Add("II Year")
              

            End If
            ddl_regstuyear.Items.Insert(0, New ListItem("-- Select Year --"))
            ddl_regstuyear.SelectedIndex = 0
            'ddl_regstdept.Items.Insert(0, " -- Choose Department --")
            'ddl_regstdept.Items(0).Selected = True
            'ddl_regstdept.Items(0).Attributes("Disabled") = "Disabled"


        Catch ex As Exception

        Finally
            db_con.Close()
        End Try
    End Sub

    
    Protected Sub ddl_regstudept_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_regstudept.SelectedIndexChanged
        'ddl_regstudept.Items(0).Selected = True
        ddl_regstudept.Items(0).Attributes("Disabled") = "Disable"

    End Sub

    Protected Sub ddl_regstuyear_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_regstuyear.SelectedIndexChanged
        'ddl_regstuyear.Items(0).Selected = True
        ddl_regstuyear.Items(0).Attributes("Disabled") = "Disable"
    End Sub

    Protected Sub txt_regstuname_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txt_regstuname.TextChanged
       
    End Sub
End Class