﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Imports System.Configuration

Public Class staffview
    Inherits System.Web.UI.Page

    Dim db_path As String
    Dim db_cmd As New SqlCommand
    Dim db_con As New SqlConnection
    Dim db_read As SqlDataReader
    Dim db_adpt As New SqlDataAdapter
    Dim db_dataset As New DataSet
    Dim db_datatable As New DataTable

    Dim stfview_check, stfview_insert As String

    Dim stfview_temp As Integer

    Dim radio_txt As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack = False Then

            If Session("staff_usersession") = Nothing Or Session("staff_usersession") = "" Then

                Response.Redirect("../Login.aspx")

            Else
                lbl_stfvseshead.Text = "Welcome : " & Session("staff_usersession")

                'sess_stfvname = Session("staff_usersession")
                'sess_stfvmbl = Session("staff_Mobile")
                'sess_stfvcour = Session("staff_Course")
                'sess_stfvdept = Session("staff_Department")

                txt_stffbname.Text = Session("staff_usersession")
                txt_stffbmbl.Text = Session("staff_Mobile")
                txt_stffbdept.Text = Session("staff_Course")
                txt_stffbcour.Text = Session("staff_Department")

                radio_stfvchoice.SelectedIndex = 3


                Try

                    db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
                    db_con = New SqlConnection(db_path)
                    db_con.Open()

                    stfview_check = "select SFBS_FBstudentID,SFBS_FBstudentName,SFBS_FBcomYear,SFBS_FBquesoneRating,SFBS_FBquestwoRating,SFBS_FBquesthreeRating,SFBS_FBquesfourRating,SFBS_FBquesfiveRating from SFBS_Feedback where SFBS_FBstaffName ='" + txt_stffbname.Text + "' and SFBS_FBstaffMobile= '" + txt_stffbmbl.Text + "' "
                    db_cmd = New SqlCommand(stfview_check, db_con)
                    db_adpt = New SqlDataAdapter(db_cmd)
                    db_dataset = New DataSet()
                    db_adpt.Fill(db_dataset)

                    grd_sftfb.DataSource = db_dataset
                    grd_sftfb.DataBind()
                    gridHeaders()

                Catch ex As Exception
                Response.Write("Data Error :- " & ex.ToString)

            Finally
                db_con.Close()

            End Try

                


            End If

        End If

    End Sub

    Private Sub gridHeaders()
        grd_sftfb.HeaderRow.Cells(0).Text = "Reg No."
        grd_sftfb.HeaderRow.Cells(1).Text = "Name"
        grd_sftfb.HeaderRow.Cells(2).Text = "Year"
        grd_sftfb.HeaderRow.Cells(3).Text = "Point 1"
        grd_sftfb.HeaderRow.Cells(4).Text = "Point 2"
        grd_sftfb.HeaderRow.Cells(5).Text = "Point 3"
        grd_sftfb.HeaderRow.Cells(6).Text = "Point 4"
        grd_sftfb.HeaderRow.Cells(7).Text = "Point 5"
    End Sub

    Protected Sub radio_stfvchoice_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_stfvchoice.SelectedIndexChanged

        If radio_stfvchoice.SelectedItem.Text = "I Year" Then

            radio_txt = "I Year"
        ElseIf radio_stfvchoice.SelectedItem.Text = "II Year" Then
            radio_txt = "II Year"
        ElseIf radio_stfvchoice.SelectedItem.Text = "III Year" Then

            radio_txt = "III Year"
        ElseIf radio_stfvchoice.SelectedItem.Text = "Over All" Then
            radio_txt = "Over All"

        End If

        Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString
            db_con = New SqlConnection(db_path)
            db_con.Open()

            If radio_txt = "Over All" Then

                stfview_check = "select SFBS_FBstudentID,SFBS_FBstudentName,SFBS_FBcomYear,SFBS_FBquesoneRating,SFBS_FBquestwoRating,SFBS_FBquesthreeRating,SFBS_FBquesfourRating,SFBS_FBquesfiveRating from SFBS_Feedback where SFBS_FBstaffName ='" + txt_stffbname.Text + "' and SFBS_FBstaffMobile= '" + txt_stffbmbl.Text + "' "

            Else
                stfview_check = "select SFBS_FBstudentID,SFBS_FBstudentName,SFBS_FBcomYear,SFBS_FBquesoneRating,SFBS_FBquestwoRating,SFBS_FBquesthreeRating,SFBS_FBquesfourRating,SFBS_FBquesfiveRating from SFBS_Feedback where SFBS_FBstaffName ='" + txt_stffbname.Text + "' and SFBS_FBstaffMobile= '" + txt_stffbmbl.Text + "' and SFBS_FBcomYear='" + radio_txt + "' "
            End If


            db_cmd = New SqlCommand(stfview_check, db_con)
            db_adpt = New SqlDataAdapter(db_cmd)
            db_dataset = New DataSet()
            db_adpt.Fill(db_dataset)

            grd_sftfb.DataSource = db_dataset
            grd_sftfb.DataBind()
            gridHeaders()



        Catch ex As Exception
            Response.Write("Error : " & ex.ToString)

        Finally
            db_con.Close()

        End Try

    End Sub
End Class