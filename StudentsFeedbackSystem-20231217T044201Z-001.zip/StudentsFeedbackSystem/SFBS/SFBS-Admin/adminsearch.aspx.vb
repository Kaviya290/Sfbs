﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Imports System.Configuration

Public Class adminsearch
    Inherits System.Web.UI.Page

    Dim db_path As String
    Dim db_cmd As New SqlCommand
    Dim db_con As New SqlConnection
    Dim db_read As SqlDataReader
    Dim db_adpt As New SqlDataAdapter
    Dim db_dataset As New DataSet
    Dim db_datatable As New DataTable

    Dim adminsrch_check, adminsrch_insert As String

    Dim adminsrch_temp As Integer

    Dim admin_SelectType, admin_selectCourse As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        

        If Page.IsPostBack = False Then

            If Session("login_userSession") = Nothing Or Session("login_userSession") = "" Then

                Response.Redirect("../Login.aspx")
            Else
                lbl_adminsearchseshead.Text = "Welcome : " & Session("login_userSession")


                panel_searchresults.Visible = False
                panel_searchControls.Visible = False

            End If
            
        End If

    End Sub

    Protected Sub radio_searchtype_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_searchtype.SelectedIndexChanged
        If radio_searchtype.SelectedItem.Text = "DEPARTMENT" Then
            admin_SelectType = "DEPARTMENT"
            Try

                db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
                db_con = New SqlConnection(db_path)
                db_con.Open()

                adminsrch_check = "select * from SFBS_Department"
                db_cmd = New SqlCommand(adminsrch_check, db_con)
                db_adpt = New SqlDataAdapter(db_cmd)
                db_dataset = New DataSet()
                db_adpt.Fill(db_dataset)

                grid_searchdata.DataSource = db_dataset
                grid_searchdata.DataBind()

                gridHeader_Department()

                radio_admcoursrch.SelectedIndex = 2
            Catch ex As Exception
                Response.Write("Error :- " & ex.ToString)
            Finally
                db_con.Close()

            End Try
            hideDDLFields()

        ElseIf radio_searchtype.SelectedItem.Text = "STAFF" Then
            admin_SelectType = "STAFF"
            Try

                db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
                db_con = New SqlConnection(db_path)
                db_con.Open()

                adminsrch_check = "select * from SFBS_STAFF"
                db_cmd = New SqlCommand(adminsrch_check, db_con)
                db_adpt = New SqlDataAdapter(db_cmd)
                db_dataset = New DataSet()
                db_adpt.Fill(db_dataset)

                grid_searchdata.DataSource = db_dataset
                grid_searchdata.DataBind()

                gridHeader_Staff()

                radio_admcoursrch.SelectedIndex = 2
            Catch ex As Exception
                Response.Write("Error :- " & ex.ToString)
            Finally
                db_con.Close()

            End Try
            showFields_Staff()

            ddl_deptClearDef()




            'ddl_deptDefault()


        ElseIf radio_searchtype.SelectedItem.Text = "STUDENT" Then
            admin_SelectType = "STUDENT"

            Try
                db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
                db_con = New SqlConnection(db_path)
                db_con.Open()

                adminsrch_check = "select * from SFBS_STUDENT"
                db_cmd = New SqlCommand(adminsrch_check, db_con)
                db_adpt = New SqlDataAdapter(db_cmd)
                db_dataset = New DataSet()
                db_adpt.Fill(db_dataset)

                grid_searchdata.DataSource = db_dataset
                grid_searchdata.DataBind()

                gridHeader_Student()

                radio_admcoursrch.SelectedIndex = 2
            Catch ex As Exception
                Response.Write("Error :- " & ex.ToString)
            Finally
                db_con.Close()

            End Try

            showDDLFields()
            ddl_yearClearDef()
        End If
        txt_adminSelectType.Text = admin_SelectType
        panel_searchresults.Visible = True
        panel_searchControls.Visible = True

        txt_adminCourSrch.Text = "Over All"
        ddl_srchdept.Enabled = False
        ddl_srchyear.Enabled = False


    End Sub


    Protected Sub radio_admcoursrch_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_admcoursrch.SelectedIndexChanged
        If radio_admcoursrch.SelectedItem.Text = "UG" Then
            admin_selectCourse = "UG"

            ddl_yearClearDef()

            ddl_srchyear.Items.Add("I Year")
            ddl_srchyear.Items.Add("II Year")
            ddl_srchyear.Items.Add("III Year")

        ElseIf radio_admcoursrch.SelectedItem.Text = "PG" Then
            admin_selectCourse = "PG"
            ddl_yearClearDef()

            ddl_srchyear.Items.Add("I Year")
            ddl_srchyear.Items.Add("II Year")

        ElseIf radio_admcoursrch.SelectedItem.Text = "Over All" Then
            admin_selectCourse = "Over All"
        End If

        txt_adminCourSrch.Text = admin_selectCourse

        'Department Retrive

        Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            adminsrch_check = "select SFBS_deptName from SFBS_Department where SFBS_deptCourse='" + txt_adminCourSrch.Text + "' "
            db_cmd = New SqlCommand(adminsrch_check, db_con)
            db_read = db_cmd.ExecuteReader()

            ddl_srchdept.DataSource = db_read
            ddl_srchdept.DataTextField = "SFBS_deptName"
            ddl_srchdept.DataValueField = "SFBS_deptName"
            ddl_srchdept.DataBind()

            ddl_deptDefault()


        Catch ex As Exception
            Response.Write("Error : " & ex.ToString)
        Finally
            db_con.Close()

        End Try

        'Data Retrives
        'Department
        If txt_adminSelectType.Text = "DEPARTMENT" Then

            Try
                db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
                db_con = New SqlConnection(db_path)
                db_con.Open()

                If txt_adminCourSrch.Text = "Over All" Then
                    adminsrch_check = "select * from SFBS_Department"
                Else
                    adminsrch_check = "select * from SFBS_Department where SFBS_deptCourse='" + txt_adminCourSrch.Text + "' "
                End If

                db_cmd = New SqlCommand(adminsrch_check, db_con)
                db_adpt = New SqlDataAdapter(db_cmd)
                db_dataset = New DataSet()
                db_adpt.Fill(db_dataset)

                grid_searchdata.DataSource = db_dataset
                grid_searchdata.DataBind()

                gridHeader_Department()
            Catch ex As Exception
                Response.Write("Error :- " & ex.ToString)
            Finally
                db_con.Close()

            End Try

            'Staff
        ElseIf txt_adminSelectType.Text = "STAFF" Then

            Try
                db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
                db_con = New SqlConnection(db_path)
                db_con.Open()


                If txt_adminCourSrch.Text = "Over All" Then

                    ddl_deptClearDef()
                    ddl_srchdept.Enabled = False

                    adminsrch_check = "select * from SFBS_STAFF"

                Else
                    ddl_srchdept.Enabled = True

                    adminsrch_check = "select * from SFBS_STAFF where SFBS_staffCourse='" + txt_adminCourSrch.Text + "'"
                End If

                db_cmd = New SqlCommand(adminsrch_check, db_con)
                db_adpt = New SqlDataAdapter(db_cmd)
                db_dataset = New DataSet()
                db_adpt.Fill(db_dataset)

                grid_searchdata.DataSource = db_dataset
                grid_searchdata.DataBind()

                gridHeader_Staff()

            Catch ex As Exception
                Response.Write("Error : " & ex.ToString)
            Finally
                db_con.Close()

            End Try

        ElseIf txt_adminSelectType.Text = "STUDENT" Then
            Try
                db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
                db_con = New SqlConnection(db_path)
                db_con.Open()

                If txt_adminCourSrch.Text = "Over All" Then

                    ddl_yearClearDef()

                    ddl_srchdept.Enabled = False
                    ddl_srchyear.Enabled = False

                    adminsrch_check = "select * from SFBS_STUDENT"
                Else
                    ddl_srchdept.Enabled = True
                    ddl_srchyear.Enabled = True

                    adminsrch_check = "select * from SFBS_STUDENT where SFBS_studentCourse ='" + txt_adminCourSrch.Text + "' "

                End If
               

                db_cmd = New SqlCommand(adminsrch_check, db_con)
                db_adpt = New SqlDataAdapter(db_cmd)
                db_dataset = New DataSet()
                db_adpt.Fill(db_dataset)

                grid_searchdata.DataSource = db_dataset
                grid_searchdata.DataBind()

                gridHeader_Student()

            Catch ex As Exception
                Response.Write("Error :- " & ex.ToString)
            Finally
                db_con.Close()

            End Try

        End If

        


    End Sub

    Private Sub gridHeader_Department()
        grid_searchdata.HeaderRow.Cells(0).Text = "COURSE"
        grid_searchdata.HeaderRow.Cells(1).Text = "ID"
        grid_searchdata.HeaderRow.Cells(2).Text = "NAME"
        grid_searchdata.HeaderRow.Cells(3).Text = "No.of STAFFS"
    End Sub

    Private Sub gridHeader_Staff()
        grid_searchdata.HeaderRow.Cells(0).Text = "NAME"
        grid_searchdata.HeaderRow.Cells(1).Text = "COURSE"
        grid_searchdata.HeaderRow.Cells(2).Text = "DEPARTMENT"
        grid_searchdata.HeaderRow.Cells(3).Text = "GENDER"
        grid_searchdata.HeaderRow.Cells(4).Text = "DESIGNATION"
        grid_searchdata.HeaderRow.Cells(5).Text = "MOBILE No."
        grid_searchdata.HeaderRow.Cells(6).Text = "DATE Of JOIN"
        grid_searchdata.HeaderRow.Cells(7).Text = "EXPERIENCE"
    End Sub

    Private Sub gridHeader_Student()
        grid_searchdata.HeaderRow.Cells(0).Text = "Reg. No"
        grid_searchdata.HeaderRow.Cells(1).Text = "NAME"
        grid_searchdata.HeaderRow.Cells(2).Text = "GENDER"
        grid_searchdata.HeaderRow.Cells(3).Text = "COURSE"
        grid_searchdata.HeaderRow.Cells(4).Text = "DEPARTMENT"
        grid_searchdata.HeaderRow.Cells(5).Text = "YEAR"
        grid_searchdata.HeaderRow.Cells(6).Text = "MAIL ID"
        grid_searchdata.HeaderRow.Cells(7).Text = "MOBILE No."
        grid_searchdata.HeaderRow.Cells(8).Text = "USER-NAME"
        grid_searchdata.HeaderRow.Cells(9).Text = "PASSWORD"
    End Sub

    Private Sub ddl_yearClearDef()
        ddl_srchyear.ClearSelection()
        ddl_srchyear.Items.Clear()
        ddl_srchyear.Items.Insert(0, New ListItem("-- Select Year --"))
        ddl_srchyear.SelectedIndex = 0
    End Sub

    Private Sub ddl_yearDefault()
        ddl_srchyear.ClearSelection()
        'ddl_srchdept.Items.Clear()

        ddl_srchyear.Items.Insert(0, New ListItem("-- Select Year --"))
        ddl_srchyear.SelectedIndex = 0
    End Sub

    Private Sub ddl_deptClearDef()
        ddl_srchdept.ClearSelection()
        ddl_srchdept.Items.Clear()
        ddl_srchdept.Items.Insert(0, New ListItem("-- Select Department --"))
        ddl_srchdept.SelectedIndex = 0
    End Sub

    Private Sub ddl_deptDefault()
        ddl_srchdept.ClearSelection()
        'ddl_srchdept.Items.Clear()

        ddl_srchdept.Items.Insert(0, New ListItem("-- Select Department --"))
        ddl_srchdept.SelectedIndex = 0
    End Sub

    Private Sub hideDDLFields()

        lbl_srchdept.Visible = False
        lbl_srchyear.Visible = False
        lbl_srchcol1.Visible = False
        lbl_srchcol3.Visible = False

        ddl_srchyear.Visible = False
        ddl_srchdept.Visible = False


    End Sub

    Private Sub showDDLFields()

        lbl_srchdept.Visible = True
        lbl_srchyear.Visible = True
        lbl_srchcol1.Visible = True
        lbl_srchcol3.Visible = True

        ddl_srchyear.Visible = True
        ddl_srchdept.Visible = True


    End Sub

    Private Sub showFields_Staff()
        lbl_srchdept.Visible = True
        lbl_srchcol1.Visible = True
        ddl_srchdept.Visible = True

        lbl_srchyear.Visible = False
        lbl_srchcol3.Visible = False
        ddl_srchyear.Visible = False
    End Sub

    Protected Sub ddl_srchdept_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_srchdept.SelectedIndexChanged
        ddl_srchdept.Items(0).Attributes("Disabled") = "Disable"


        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()
            If txt_adminSelectType.Text = "STAFF" Then
                adminsrch_check = "select * from SFBS_STAFF where SFBS_staffCourse='" + txt_adminCourSrch.Text + "' and SFBS_staffDept='" + ddl_srchdept.SelectedItem.Text + "' "

            ElseIf txt_adminSelectType.Text = "STUDENT" Then

                adminsrch_check = "select * from SFBS_STUDENT where SFBS_studentCourse='" + txt_adminCourSrch.Text + "' and SFBS_studentDept='" + ddl_srchdept.SelectedItem.Text + "' "

            End If
            db_cmd = New SqlCommand(adminsrch_check, db_con)
            db_adpt = New SqlDataAdapter(db_cmd)
            db_dataset = New DataSet()
            db_adpt.Fill(db_dataset)

            grid_searchdata.DataSource = db_dataset
            grid_searchdata.DataBind()

            If txt_adminSelectType.Text = "STAFF" Then
                gridHeader_Staff()
            ElseIf txt_adminSelectType.Text = "STUDENT" Then
                gridHeader_Student()

            End If

        Catch ex As Exception

        Finally
            db_con.Close()

        End Try
        ddl_srchyear.SelectedIndex = 0



    End Sub

    Protected Sub ddl_srchyear_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_srchyear.SelectedIndexChanged
        ddl_srchyear.Items(0).Attributes("Disabled") = "Disable"

        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            If ddl_srchdept.SelectedItem.Text = "-- Select Department --" Or ddl_srchdept.SelectedItem.Text = "" Then
                adminsrch_check = "select * from SFBS_STUDENT where SFBS_studentCourse='" + txt_adminCourSrch.Text + "' and SFBS_studentYear='" + ddl_srchyear.SelectedItem.Text + "'"
            Else
                adminsrch_check = "select * from SFBS_STUDENT where SFBS_studentCourse='" + txt_adminCourSrch.Text + "' and SFBS_studentDept='" + ddl_srchdept.SelectedItem.Text + "' and SFBS_studentYear='" + ddl_srchyear.SelectedItem.Text + "'"
            End If

            db_cmd = New SqlCommand(adminsrch_check, db_con)
            db_adpt = New SqlDataAdapter(db_cmd)
            db_dataset = New DataSet()
            db_adpt.Fill(db_dataset)

            grid_searchdata.DataSource = db_dataset
            grid_searchdata.DataBind()

            gridHeader_Student()


        Catch ex As Exception

        Finally
            db_con.Close()

        End Try

    End Sub
End Class