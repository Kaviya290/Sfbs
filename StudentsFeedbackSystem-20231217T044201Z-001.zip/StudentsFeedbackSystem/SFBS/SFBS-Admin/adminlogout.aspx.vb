﻿Public Class adminlogout
    Inherits System.Web.UI.Page

    Dim ses_timeout As Integer


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        lbl_adminlogoutmsg.Text = Session("login_userSession")

        Session().RemoveAll()
        Session().Abandon()
        Session().Clear()
        Response.Cookies.Clear()

        Response.Redirect("../Login.aspx")




    End Sub

    Private Sub adminlogout_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        
    End Sub
End Class