﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Imports System.Configuration

Public Class studentfeedback
    Inherits System.Web.UI.Page

    Dim db_path As String
    Dim db_cmd As New SqlCommand
    Dim db_con As New SqlConnection
    Dim db_read As SqlDataReader
    Dim db_adpt As New SqlDataAdapter
    Dim db_datatable As New DataTable

    Dim studfb_check, studfb_insert As String

    Dim studfb_temp As Integer

    Dim sessfb_stuname, sessfb_sturegno, sessfb_stucour, sessfb_studept, bg_staffMobile, bg_stuYear As String

    Dim stf_score01, stf_score02, stf_score03, stf_score04, stf_score05, stf_totalscore As Integer


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        panel_feedbackstaff.Visible = False

        If Page.IsPostBack = False Then

            If Session("student_usersession") = "" Or Session("student_usersession") = Nothing Then
                Response.Redirect("../Login.aspx")
            Else

                lbl_stufeedseshead.Text = "Welcome : " & Session("student_usersession")
                sessfb_stuname = Session("student_usersession")
                sessfb_sturegno = Session("student_regno")

                sessfb_stucour = Session("student_Course")
                sessfb_studept = Session("student_Dept")

                Try

                    db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString
                    db_con = New SqlConnection(db_path)

                    studfb_check = "select * from SFBS_STUDENT where SFBS_studentName ='" + sessfb_stuname + "' and SFBS_studentRegno='" + sessfb_sturegno + "' "
                    db_cmd = New SqlCommand(studfb_check, db_con)
                    db_con.Open()

                    db_read = db_cmd.ExecuteReader()

                    db_read.Read()

                    txt_studFBRegno.Text = db_read("SFBS_studentRegno").ToString
                    txt_studFBName.Text = db_read("SFBS_studentName").ToString
                    txt_studFBYear.Text = db_read("SFBS_studentYear").ToString


                Catch ex As Exception
                    Response.Write("Error " & ex.ToString)
                Finally
                    db_read.Close()
                    db_con.Close()

                End Try


                Try
                    db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
                    db_con = New SqlConnection(db_path)
                    db_con.Open()

                    studfb_check = "select SFBS_staffName,SFBS_staffMobile from SFBS_STAFF where SFBS_staffCourse = '" + sessfb_stucour + "' and SFBS_staffDept= '" + sessfb_studept + "' "

                    db_cmd = New SqlCommand(studfb_check, db_con)
                    db_read = db_cmd.ExecuteReader()

                    'While db_read.Read()
                    'bg_staffMobile = db_read("SFBS_staffMobile").ToString
                    'Response.Write(bg_staffMobile)
                    'End While



                    db_read.Close()

                    db_read = db_cmd.ExecuteReader()


                    ddl_stafflistFB.DataSource = db_read

                    ddl_stafflistFB.DataTextField = "SFBS_staffName"
                    ddl_stafflistFB.DataValueField = "SFBS_staffMobile"
                    ddl_stafflistFB.DataBind()

                    ddl_stafflistFB.Items.Insert(0, New ListItem("-- Select Staff --"))
                    ddl_stafflistFB.SelectedIndex = 0


                Catch ex As Exception
                    Response.Write("Error " & ex.ToString)
                Finally
                    db_read.Close()
                    db_con.Close()

                End Try

            End If

            

        End If

    End Sub

    Protected Sub ddl_stafflistFB_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_stafflistFB.SelectedIndexChanged

        ddl_stafflistFB.Items(0).Attributes("Disabled") = "Disabled"

        
            

            Try
            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            studfb_check = "select SFBS_staffName, SFBS_staffCourse,SFBS_staffDept,SFBS_staffMobile from SFBS_STAFF where SFBS_staffMobile ='" + ddl_stafflistFB.SelectedValue + "' "
            db_cmd = New SqlCommand(studfb_check, db_con)
            db_read = db_cmd.ExecuteReader()

            db_read.Read()



            txt_staffName.Text = db_read("SFBS_staffName").ToString
            txt_staffDept.Text = db_read("SFBS_staffDept").ToString
            txt_staffCourse.Text = db_read("SFBS_staffCourse").ToString
            'txt_hdstfMobile.Text = db_read("SFBS_staffMobile").ToString
            bg_staffMobile = db_read("SFBS_staffMobile").ToString

            db_con.Close()

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()
            studfb_check = "select count(*) from SFBS_Feedback where SFBS_FBstudentID='" + txt_studFBRegno.Text + "' and SFBS_FBstaffMobile='" + bg_staffMobile + "'"
            db_cmd = New SqlCommand(studfb_check, db_con)
            studfb_temp = Convert.ToInt32(db_cmd.ExecuteScalar().ToString)


            If studfb_temp = 1 Then
                lbl_namechkmsg.Visible = True
                lbl_namechkmsg.Text = "Already Feedback Registered"
            Else
                lbl_namechkmsg.Visible = False
                panel_feedbackstaff.Visible = True
            End If

            db_con.Close()

            Catch ex As Exception
            Response.Write("Error :- " & ex.ToString)
            Finally

            End Try

            'resetFields()

            'Response.Write("Mobile :- " & bg_staffMobile)



            'If ddl_stafflistFB.SelectedItem.Text = "STAFF 1" Then
            'panel_feedbackstaff.Visible = True
            'txt_staffname.Text = ddl_stafflistFB.SelectedItem.Text
            'ElseIf ddl_stafflistFB.SelectedItem.Text = "STAFF 2" Then
            'panel_feedbackstaff.Visible = True
            'txt_staffname.Text = ddl_stafflistFB.SelectedItem.Text
            'End If

    End Sub

   

    Protected Sub btn_feedsubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btn_feedsubmit.Click

        Try

            stf_totalscore = stf_score01 + stf_score02 + stf_score03 + stf_score04 + stf_score05


            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            studfb_insert = "insert into SFBS_Feedback (SFBS_FBstudentID,SFBS_FBstudentName,SFBS_FBcomYear,SFBS_FBcomCourse,SFBS_FBstaffName,SFBS_FBstaffDept,SFBS_FBstaffMobile,SFBS_FBquesoneRating,SFBS_FBquestwoRating,SFBS_FBquesthreeRating,SFBS_FBquesfourRating,SFBS_FBquesfiveRating,SFBS_FBtotalRating) values ('" & txt_studFBRegno.Text & "','" & txt_studFBName.Text & "','" & txt_studFBYear.Text & "', '" & txt_staffCourse.Text & "','" & txt_staffName.Text & "','" & txt_staffDept.Text & "','" & ddl_stafflistFB.SelectedValue & "','" & stf_score01 & "','" & stf_score02 & "','" & stf_score03 & "','" & stf_score04 & "','" & stf_score05 & "','" & stf_totalscore & "') "



            db_cmd = New SqlCommand(studfb_insert, db_con)
            db_cmd.ExecuteNonQuery()

            'Response.Write(txt_studFBRegno.Text & " " & txt_staffName.Text & " " & txt_studFBName.Text & " " & txt_staffCourse.Text & " " & ddl_stafflistFB.SelectedValue)

            lbl_namechkmsg.Visible = True
            lbl_namechkmsg.Text = "Feedback Submitted Successfully"
            resetFields()

        Catch ex As Exception
            Response.Write(ex.ToString)
        Finally
            db_con.Close()


        End Try

        ' Response.Write("Ans 1 :- " & radio_feedans1.SelectedItem.Text & " Point :-  " & stf_score01 & ", Ans 2 :- " & radio_feedans2.SelectedItem.Text & " Point :-  " & stf_score02 & "Ans 3 :- " & radio_feedans3.SelectedItem.Text & " Point :-  " & stf_score03 & "Ans 4 :- " & radio_feedans4.SelectedItem.Text & " Point :-  " & stf_score04 & "Ans 5 :- " & radio_feedans5.SelectedItem.Text & " Point :-  " & stf_score05)

    End Sub

    Protected Sub radio_feedans_1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_feedans1.SelectedIndexChanged
        If radio_feedans1.SelectedItem.Text = "Excellent" Then
            stf_score01 = 5
        ElseIf radio_feedans1.SelectedItem.Text = "Best" Then
            stf_score01 = 4
        ElseIf radio_feedans1.SelectedItem.Text = "Good" Then
            stf_score01 = 3
        ElseIf radio_feedans1.SelectedItem.Text = "Average" Then
            stf_score01 = 2
        ElseIf radio_feedans1.SelectedItem.Text = "Poor" Then
            stf_score01 = 1
        End If
    End Sub

    Protected Sub radio_feedans2_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_feedans2.SelectedIndexChanged
        If radio_feedans2.SelectedItem.Text = "Excellent" Then
            stf_score02 = 5
        ElseIf radio_feedans2.SelectedItem.Text = "Best" Then
            stf_score02 = 4
        ElseIf radio_feedans2.SelectedItem.Text = "Good" Then
            stf_score02 = 3
        ElseIf radio_feedans2.SelectedItem.Text = "Average" Then
            stf_score02 = 2
        ElseIf radio_feedans2.SelectedItem.Text = "Poor" Then
            stf_score02 = 1
        End If
    End Sub

    Protected Sub radio_feedans3_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_feedans3.SelectedIndexChanged
        If radio_feedans3.SelectedItem.Text = "Excellent" Then
            stf_score03 = 5
        ElseIf radio_feedans3.SelectedItem.Text = "Best" Then
            stf_score03 = 4
        ElseIf radio_feedans3.SelectedItem.Text = "Good" Then
            stf_score03 = 3
        ElseIf radio_feedans3.SelectedItem.Text = "Average" Then
            stf_score03 = 2
        ElseIf radio_feedans3.SelectedItem.Text = "Poor" Then
            stf_score03 = 1
        End If
    End Sub

    Protected Sub radio_feedans4_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_feedans4.SelectedIndexChanged
        If radio_feedans4.SelectedItem.Text = "Excellent" Then
            stf_score04 = 5
        ElseIf radio_feedans4.SelectedItem.Text = "Best" Then
            stf_score04 = 4
        ElseIf radio_feedans4.SelectedItem.Text = "Good" Then
            stf_score04 = 3
        ElseIf radio_feedans4.SelectedItem.Text = "Average" Then
            stf_score04 = 2
        ElseIf radio_feedans4.SelectedItem.Text = "Poor" Then
            stf_score04 = 1
        End If
    End Sub

    Protected Sub radio_feedans5_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_feedans5.SelectedIndexChanged
        If radio_feedans5.SelectedItem.Text = "Excellent" Then
            stf_score05 = 5
        ElseIf radio_feedans5.SelectedItem.Text = "Best" Then
            stf_score05 = 4
        ElseIf radio_feedans5.SelectedItem.Text = "Good" Then
            stf_score05 = 3
        ElseIf radio_feedans5.SelectedItem.Text = "Average" Then
            stf_score05 = 2
        ElseIf radio_feedans5.SelectedItem.Text = "Poor" Then
            stf_score05 = 1
        End If
    End Sub


    Private Sub resetFields()

        radio_feedans1.ClearSelection()
        radio_feedans2.ClearSelection()
        radio_feedans3.ClearSelection()
        radio_feedans4.ClearSelection()
        radio_feedans5.ClearSelection()

        'ddl_stafflistFB.Items.Insert(0, New ListItem("-- Select Staff --"))
        ddl_stafflistFB.SelectedIndex = 0


    End Sub

    
End Class