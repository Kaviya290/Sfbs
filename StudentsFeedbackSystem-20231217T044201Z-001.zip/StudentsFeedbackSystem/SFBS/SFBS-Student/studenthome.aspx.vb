﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Imports System.Configuration

Public Class studenthome
    Inherits System.Web.UI.Page

    Dim db_path As String
    Dim db_cmd As New SqlCommand
    Dim db_con As New SqlConnection
    Dim db_read As SqlDataReader
    Dim db_adpt As New SqlDataAdapter
    Dim db_datatable As New DataTable

    Dim student_check, student_insert As String

    Dim student_temp As Integer

    Dim sess_stuname, sess_sturegno As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack = False Then

            If Session("student_usersession") = Nothing Or Session("student_usersession") = "" Then

                Response.Redirect("../Login.aspx")
            Else

                lbl_stuhomeseshead.Text = "Welcome : " & Session("student_usersession")
                sess_stuname = Session("student_usersession")
                sess_sturegno = Session("student_regno")

                Try


                    db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString
                    db_con = New SqlConnection(db_path)


                    student_check = "select * from SFBS_STUDENT where SFBS_studentName = '" + sess_stuname + "' and SFBS_studentRegno = '" + sess_sturegno + "' "
                    db_cmd = New SqlCommand(student_check, db_con)
                    db_con.Open()

                    db_read = db_cmd.ExecuteReader()

                    db_read.Read()

                    txt_sturegid.Text = db_read("SFBS_studentRegno").ToString
                    txt_stuname.Text = db_read("SFBS_studentName").ToString
                    txt_stugender.Text = db_read("SFBS_studentGender").ToString
                    txt_stucourse.Text = db_read("SFBS_studentCourse").ToString
                    txt_studept.Text = db_read("SFBS_studentDept").ToString
                    txt_stuyear.Text = db_read("SFBS_studentYear").ToString
                    txt_stumail.Text = db_read("SFBS_studentMailid").ToString
                    txt_stuphone.Text = db_read("SFBS_studentMobile").ToString


                Catch ex As Exception
                    Response.Write(ex.ToString)

                Finally
                    db_read.Close()
                    db_con.Close()

                End Try

            End If

        End If

    End Sub

End Class