﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Imports System.Configuration
Imports System.Web.UI.DataVisualization.Charting

Public Class adminreport
    Inherits System.Web.UI.Page

    Dim db_path As String
    Dim db_cmd As New SqlCommand
    Dim db_con As New SqlConnection
    Dim db_read As SqlDataReader
    Dim db_adpt As New SqlDataAdapter
    Dim db_dataset As New DataSet
    Dim db_datatable As New DataTable

    Dim report_check, report_insert As String

    Dim report_temp As Integer

    Dim chart_Series As Series

    Dim report_SelectType, report_selectCourse As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("login_userSession") = Nothing Or Session("login_userSession") = "" Then
            Response.Redirect("../Login.aspx")
        Else
            lbl_reportsearchseshead.Text = "Welcome : " & Session("login_userSession")
        End If


    End Sub

    Protected Sub radio_rptcour_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles radio_rptcour.SelectedIndexChanged

        If radio_rptcour.SelectedItem.Text = "UG" Then
            report_selectCourse = "UG"

            ddl_yearclearDef()

            ddl_rptclass.Items.Add("I Year")
            ddl_rptclass.Items.Add("II Year")
            ddl_rptclass.Items.Add("III Year")
            ddl_rptclass.Items.Add("Over All")

        ElseIf radio_rptcour.SelectedItem.Text = "PG" Then
            report_selectCourse = "PG"

            ddl_yearclearDef()
            ddl_rptclass.Items.Add("I Year")
            ddl_rptclass.Items.Add("II Year")
            ddl_rptclass.Items.Add("Over All")
        End If

        txt_hideCourse.Text = report_selectCourse

        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            report_check = "select SFBS_deptName from SFBS_Department where SFBS_deptCourse= '" + txt_hideCourse.Text + "' "
            db_cmd = New SqlCommand(report_check, db_con)
            db_read = db_cmd.ExecuteReader()

            ddl_rptdept.DataSource = db_read
            ddl_rptdept.DataTextField = "SFBS_deptName"
            ddl_rptdept.DataValueField = "SFBS_deptName"
            ddl_rptdept.DataBind()

            ddl_deptDefault()

        Catch ex As Exception
            Response.Write("Connection Error : " & ex.ToString)
        Finally
            db_con.Close()
        End Try
        ddl_staffDefault()
        lbl_chartHead.Visible = False

    End Sub

    Private Sub ddl_deptClearDef()
        ddl_rptdept.ClearSelection()
        ddl_rptdept.Items.Clear()
        ddl_rptdept.Items.Insert(0, New ListItem("-- Select Department --"))
        ddl_rptdept.SelectedIndex = 0
    End Sub

    Private Sub ddl_deptDefault()
        ddl_rptdept.ClearSelection()
        ddl_rptdept.Items.Insert(0, New ListItem("-- Select Department --"))
        ddl_rptdept.SelectedIndex = 0
    End Sub

    Private Sub ddl_staffDefault()
        ddl_rptname.ClearSelection()
        ddl_rptname.Items.Insert(0, New ListItem("-- Select Name --"))
        ddl_rptname.SelectedIndex = 0
    End Sub

    Private Sub ddl_yearclearDef()
        ddl_rptclass.ClearSelection()
        ddl_rptclass.Items.Clear()
        ddl_rptclass.Items.Insert(0, New ListItem("-- Select Year --"))
        ddl_rptclass.SelectedIndex = 0
    End Sub
    Private Sub ddl_yearDefault()
        ddl_rptclass.ClearSelection()
        'ddl_rptclass.Items.Insert(0, New ListItem("-- Select Year --"))
        ddl_rptclass.SelectedIndex = 0
    End Sub

    Protected Sub ddl_rptdept_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_rptdept.SelectedIndexChanged

        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            report_check = "select SFBS_staffName,SFBS_staffMobile from SFBS_STAFF where SFBS_staffDept= '" + ddl_rptdept.SelectedItem.Text + "' and SFBS_staffCourse ='" + txt_hideCourse.Text + "' "

            db_cmd = New SqlCommand(report_check, db_con)
            db_read = db_cmd.ExecuteReader()

            ddl_rptname.DataSource = db_read
            ddl_rptname.DataTextField = "SFBS_staffName"
            ddl_rptname.DataValueField = "SFBS_staffMobile"
            ddl_rptname.DataBind()

            ddl_staffDefault()
            ddl_yearDefault()
            disableIndex_Zero()
        Catch ex As Exception
            Response.Write("Error : " & ex.ToString)
        Finally
            db_con.Close()
        End Try
        lbl_chartHead.Visible = False
    End Sub

    Protected Sub ddl_rptname_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_rptname.SelectedIndexChanged

        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            report_check = "select SFBS_FBstudentName,SFBS_FBstaffName,SFBS_FBtotalRating from SFBS_Feedback where SFBS_FBstaffMobile = '" + ddl_rptname.SelectedValue + "' "
            db_cmd = New SqlCommand(report_check, db_con)

            chart_Series = chart_ratings.Series("Series_Ratings")

            db_read = db_cmd.ExecuteReader()

            While db_read.Read
                chart_Series.Points.AddXY(db_read("SFBS_FBstudentName").ToString, db_read("SFBS_FBtotalRating"))
            End While

            chart_ratings.Legends(0).Enabled = True



        Catch ex As Exception
            Response.Write("Error : " & ex.ToString)
        Finally
            db_con.Close()

        End Try

        ddl_yearDefault()
        disableIndex_Zero()

        lbl_chartHead.Text = "RATINGS OF OVERALL - " & ddl_rptdept.SelectedItem.Text & " DEPARTMENT CLASSES"

    End Sub

    Protected Sub ddl_rptclass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddl_rptclass.SelectedIndexChanged


        Try

            db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString()
            db_con = New SqlConnection(db_path)
            db_con.Open()

            If ddl_rptclass.SelectedItem.Text = "Over All" Then

                report_check = "select SFBS_FBstudentName,SFBS_FBstaffName,SFBS_FBtotalRating from SFBS_Feedback where SFBS_FBstaffMobile = '" + ddl_rptname.SelectedValue + "' "
            Else

                report_check = "select SFBS_FBstudentName,SFBS_FBstaffName,SFBS_FBtotalRating from SFBS_Feedback where SFBS_FBstaffMobile = '" + ddl_rptname.SelectedValue + "' and SFBS_FBcomYear='" + ddl_rptclass.SelectedItem.Text + "' "
            End If

            db_cmd = New SqlCommand(report_check, db_con)

            chart_Series = chart_ratings.Series("Series_Ratings")

            db_read = db_cmd.ExecuteReader()

            While db_read.Read
                chart_Series.Points.AddXY(db_read("SFBS_FBstudentName").ToString, db_read("SFBS_FBtotalRating"))
            End While

            chart_ratings.Legends(0).Enabled = True



        Catch ex As Exception
            Response.Write("Error : " & ex.ToString)
        Finally
            db_con.Close()

        End Try

        disableIndex_Zero()
        lbl_chartHead.Text = "RATINGS OF " & ddl_rptclass.SelectedItem.Text & " CLASS - " & ddl_rptdept.SelectedItem.Text
    End Sub

    Private Sub disableIndex_Zero()
        ddl_rptname.Items(0).Attributes("Disabled") = "Disable"
        ddl_rptclass.Items(0).Attributes("Disabled") = "Disable"
        ddl_rptdept.Items(0).Attributes("Disabled") = "Disable"

    End Sub
End Class