﻿Public Class adminhome
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack = False Then
            If Session("login_userSession") = Nothing Or Session("login_userSession") = "" Then
                Response.Redirect("../Login.aspx")
            Else
                lbl_adminhomeseshead.Text = "Welcome : " + Session("login_userSession")

            End If
        End If


    End Sub

End Class