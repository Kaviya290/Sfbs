﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlClient.SqlException
Imports System.Configuration

Public Class staffhome
    Inherits System.Web.UI.Page


    Dim db_path As String
    Dim db_cmd As New SqlCommand
    Dim db_con As New SqlConnection
    Dim db_read As SqlDataReader
    Dim db_adpt As New SqlDataAdapter
    Dim db_datatable As New DataTable

    Dim staff_check, staff_insert As String

    Dim staff_temp As Integer

    Dim sess_stfname, sess_stfmbl As String


    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        If Page.IsPostBack = False Then

            If Session("staff_usersession") = Nothing Or Session("staff_usersession") = "" Then

                Response.Redirect("../Login.aspx")
            Else


                lbl_staffseshead.Text = "Welcome : " & Session("staff_usersession")

                sess_stfname = Session("staff_usersession")
                sess_stfmbl = Session("staff_Mobile")


                Try


                    db_path = ConfigurationManager.ConnectionStrings("SFBS-Conn").ConnectionString.ToString
                    db_con = New SqlConnection(db_path)


                    staff_check = "select * from SFBS_STAFF where SFBS_staffMobile = '" + sess_stfmbl + "' and SFBS_staffName = '" + sess_stfname + "' "
                    db_cmd = New SqlCommand(staff_check, db_con)
                    db_con.Open()

                    db_read = db_cmd.ExecuteReader()

                    db_read.Read()

                    txt_staffname.Text = db_read("SFBS_staffName").ToString
                    txt_staffdept.Text = db_read("SFBS_staffCourse").ToString & "-" & db_read("SFBS_staffDept").ToString
                    txt_staffgender.Text = db_read("SFBS_staffGender").ToString
                    txt_staffdesi.Text = db_read("SFBS_staffDesignation").ToString
                    txt_staffmbl.Text = db_read("SFBS_staffMobile").ToString
                    txt_staffdoj.Text = db_read("SFBS_staffDOJ")
                    txt_staffexp.Text = db_read("SFBS_staffExp").ToString


                Catch ex As Exception
                    Response.Write(ex.ToString)

                Finally
                    db_read.Close()
                    db_con.Close()

                End Try

            End If
        End If

    End Sub

End Class